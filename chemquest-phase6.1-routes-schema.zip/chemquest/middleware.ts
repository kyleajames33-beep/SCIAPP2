import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'chemquest-secret-key-change-in-production'
);

const COOKIE_NAME = 'chemquest-auth';

// Routes that require authentication
const PROTECTED_ROUTES = ['/hub', '/campaign', '/battle', '/training', '/shop', '/profile', '/dashboard'];

// Routes that should redirect to hub if already authenticated
const AUTH_ROUTES = ['/auth/login', '/auth/register'];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get(COOKIE_NAME)?.value;

  // Check if the current path matches any protected route
  const isProtectedRoute = PROTECTED_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(route + '/')
  );

  const isAuthRoute = AUTH_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(route + '/')
  );

  let isValidToken = false;

  if (token) {
    try {
      await jwtVerify(token, JWT_SECRET);
      isValidToken = true;
    } catch {
      // Token invalid/expired — treated as unauthenticated
    }
  }

  // Redirect unauthenticated users away from protected routes
  if (isProtectedRoute && !isValidToken) {
    const loginUrl = new URL('/auth/login', request.url);
    loginUrl.searchParams.set('callbackUrl', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Redirect authenticated users away from auth pages to hub
  if (isAuthRoute && isValidToken) {
    return NextResponse.redirect(new URL('/hub', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/hub/:path*',
    '/campaign/:path*',
    '/battle/:path*',
    '/training/:path*',
    '/shop/:path*',
    '/profile/:path*',
    '/dashboard/:path*',
    '/auth/:path*',
  ],
};
