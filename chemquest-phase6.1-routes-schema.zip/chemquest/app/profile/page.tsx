'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  User, Trophy, Coins, Flame, Target, Gamepad2,
  ArrowLeft, Loader2, LogOut, Clock, Crown, Sparkles, RotateCcw
} from 'lucide-react'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { getModeDisplay } from '@/lib/game-config'
import { UpgradeShop } from './_components/upgrade-shop'
import { ReferralCard } from './_components/referral-card'

interface UserProfile {
  id: string
  username: string
  displayName: string
  email: string | null
  role: string
  totalCoins: number
  totalScore: number
  gamesPlayed: number
  bestStreak: number
  prestigeLevel: number
  lifetimeEarnings: number
}

interface GameHistory {
  id: string
  gameMode: string
  score: number
  accuracy: number
  maxStreak: number
  totalQuestions: number
  completedAt: string
}

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<UserProfile | null>(null)
  const [recentGames, setRecentGames] = useState<GameHistory[]>([])
  const [userUpgrades, setUserUpgrades] = useState<Record<string, number>>({})
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch('/api/profile')
        if (response.status === 401) {
          router.push('/auth/login')
          return
        }
        const data = await response.json()
        setUser(data.user)
        setRecentGames(data.recentGames || [])

        // Fetch user upgrades
        if (data.user?.id) {
          const upgradesResponse = await fetch(`/api/game/action?userId=${data.user.id}`)
          if (upgradesResponse.ok) {
            const upgradesData = await upgradesResponse.json()
            setUserUpgrades(upgradesData.userUpgrades || {})
          }
        }
      } catch (error) {
        console.error('Failed to fetch profile:', error)
        toast.error('Failed to load profile')
      } finally {
        setIsLoading(false)
      }
    }

    fetchProfile()
  }, [router])

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      toast.success('Logged out successfully')
      router.push('/')
      router.refresh()
    } catch (error) {
      console.error('Logout error:', error)
      toast.error('Failed to logout')
    }
  }

  const handlePurchase = async (upgradeId: string, cost: number) => {
    if (!user) return

    // Optimistically update UI
    const previousCoins = user.totalCoins
    const previousLevel = userUpgrades[upgradeId] || 0

    try {
      // Update local state immediately for instant feedback
      setUser(prev => prev ? { ...prev, totalCoins: prev.totalCoins - cost } : null)
      setUserUpgrades(prev => ({
        ...prev,
        [upgradeId]: (prev[upgradeId] || 0) + 1
      }))

      const response = await fetch('/api/game/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'BUY_UPGRADE',
          payload: {
            userId: user.id,
            upgradeId: upgradeId,
          },
        }),
      })

      const data = await response.json()

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to purchase upgrade')
      }

      // Update with actual values from server
      setUser(prev => prev ? { ...prev, totalCoins: data.remainingCoins } : null)
      setUserUpgrades(prev => ({
        ...prev,
        [upgradeId]: data.newLevel
      }))

      toast.success(`Upgrade purchased! Now level ${data.newLevel}`)
    } catch (error) {
      // Revert optimistic updates on error
      setUser(prev => prev ? { ...prev, totalCoins: previousCoins } : null)
      setUserUpgrades(prev => ({
        ...prev,
        [upgradeId]: previousLevel
      }))

      console.error('Purchase error:', error)
      toast.error(error instanceof Error ? error.message : 'Failed to purchase upgrade')
    }
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-AU', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-purple-300 animate-spin" />
      </div>
    )
  }

  if (!user) {
    return null
  }

  const totalAnswered = recentGames.reduce((sum, g) => sum + g.totalQuestions, 0)
  const avgAccuracy = recentGames.length > 0
    ? Math.round(recentGames.reduce((sum, g) => sum + g.accuracy, 0) / recentGames.length)
    : 0

  // Prestige requirements
  const PRESTIGE_REQUIREMENT = 100000
  const canPrestige = user?.lifetimeEarnings >= PRESTIGE_REQUIREMENT
  const coinMultiplier = 1 + (user?.prestigeLevel || 0) * 0.1

  const handlePrestige = async () => {
    if (!canPrestige) {
      toast.error(`You need ${PRESTIGE_REQUIREMENT.toLocaleString()} lifetime coins to prestige!`)
      return
    }

    const confirmed = window.confirm(
      `Prestige will reset your coins and upgrades, but you'll gain:\n` +
      `• +1 Prestige Level\n` +
      `• Permanent +10% coin multiplier (total: ${((user?.prestigeLevel || 0) + 1) * 10}%)\n\n` +
      `Are you sure?`
    )

    if (!confirmed) return

    try {
      const response = await fetch('/api/game/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'PRESTIGE',
          payload: { userId: user?.id }
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setUser(prev => prev ? {
          ...prev,
          prestigeLevel: data.prestigeLevel,
          totalCoins: 0,
          lifetimeEarnings: data.lifetimeEarnings
        } : null)
        setUserUpgrades({})
        toast.success(`🎉 Prestige ${data.prestigeLevel} Achieved! +${data.prestigeLevel * 10}% coin multiplier!`)
      } else {
        toast.error('Failed to prestige')
      }
    } catch (error) {
      toast.error('Failed to prestige')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4 py-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                <User className="w-8 h-8" />
                Profile
              </h1>
              <p className="text-purple-200">Your ChemQuest journey</p>
            </div>
          </div>
          <Button
            variant="ghost"
            className="text-red-300 hover:text-red-200 hover:bg-red-500/20"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </motion.div>

        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20 mb-6">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">
                    {user.displayName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <CardTitle className="text-white flex items-center gap-2">
                    {user.displayName}
                    {user.role === 'teacher' && (
                      <Badge className="bg-blue-500">Teacher</Badge>
                    )}
                    {user.role === 'admin' && (
                      <Badge className="bg-red-500">Admin</Badge>
                    )}
                  </CardTitle>
                  <CardDescription className="text-purple-200">@{user.username}</CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>
        </motion.div>

        {/* Prestige Banner */}
        {user.prestigeLevel > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 }}
            className="mb-6"
          >
            <Card className="bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/20 border-yellow-400/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="text-yellow-400 font-bold text-lg">Prestige Level {user.prestigeLevel}</p>
                    <p className="text-yellow-200/80 text-sm">+{user.prestigeLevel * 10}% Coin Multiplier Active</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-yellow-400">{coinMultiplier.toFixed(1)}x</p>
                  <p className="text-yellow-200/60 text-xs">Earnings</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
        >
          <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border-yellow-500/20">
            <CardContent className="p-4 text-center">
              <Coins className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-400">{user.totalCoins.toLocaleString()}</p>
              <p className="text-yellow-200 text-sm">Total Coins</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border-purple-500/20">
            <CardContent className="p-4 text-center">
              <Trophy className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-400">{user.totalScore.toLocaleString()}</p>
              <p className="text-purple-200 text-sm">Total Score</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border-blue-500/20">
            <CardContent className="p-4 text-center">
              <Gamepad2 className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-400">{user.gamesPlayed}</p>
              <p className="text-blue-200 text-sm">Games Played</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-orange-500/20 to-orange-600/10 border-orange-500/20">
            <CardContent className="p-4 text-center">
              <Flame className="w-8 h-8 text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-400">{user.bestStreak}</p>
              <p className="text-orange-200 text-sm">Best Streak</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Prestige Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mb-6"
        >
          <Card className={`border-2 transition-all ${
            canPrestige 
              ? 'bg-gradient-to-br from-red-900/40 to-orange-900/40 border-red-500/50 hover:border-red-400' 
              : 'bg-white/10 border-white/20'
          }`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    canPrestige 
                      ? 'bg-gradient-to-br from-red-500 to-orange-500 animate-pulse' 
                      : 'bg-gray-700'
                  }`}>
                    <RotateCcw className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                      Prestige
                      {canPrestige && <Badge className="bg-red-500 animate-pulse">Ready!</Badge>}
                    </h3>
                    <p className="text-gray-300 text-sm">
                      {canPrestige 
                        ? 'Reset progress for permanent bonuses!' 
                        : `Reach ${PRESTIGE_REQUIREMENT.toLocaleString()} lifetime coins to unlock`}
                    </p>
                    <div className="mt-2 flex items-center gap-4 text-sm">
                      <span className="text-gray-400">
                        Lifetime: <span className="text-yellow-400">{user.lifetimeEarnings?.toLocaleString() || 0}</span> 🪙
                      </span>
                      <span className="text-gray-500">/</span>
                      <span className="text-gray-400">
                        Goal: <span className="text-yellow-400">{PRESTIGE_REQUIREMENT.toLocaleString()}</span> 🪙
                      </span>
                    </div>
                  </div>
                </div>
                <Button
                  onClick={handlePrestige}
                  disabled={!canPrestige}
                  className={`px-6 py-6 text-lg font-bold ${
                    canPrestige 
                      ? 'bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white' 
                      : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {canPrestige ? 'Prestige Now!' : 'Locked'}
                </Button>
              </div>
              {!canPrestige && (
                <div className="mt-4 w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-yellow-500 to-orange-500 h-full transition-all"
                    style={{ width: `${Math.min(100, (user.lifetimeEarnings / PRESTIGE_REQUIREMENT) * 100)}%` }}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Additional Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-2 gap-4 mb-6"
        >
          <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20">
            <CardContent className="p-4 flex items-center gap-4">
              <Target className="w-10 h-10 text-green-400" />
              <div>
                <p className="text-2xl font-bold text-green-400">{avgAccuracy}%</p>
                <p className="text-purple-200 text-sm">Avg Accuracy</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20">
            <CardContent className="p-4 flex items-center gap-4">
              <Crown className="w-10 h-10 text-pink-400" />
              <div>
                <p className="text-2xl font-bold text-pink-400">{totalAnswered}</p>
                <p className="text-purple-200 text-sm">Questions Answered</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Referral Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
        >
          <ReferralCard />
        </motion.div>

        {/* Tabs for Upgrades and Recent Games */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Tabs defaultValue="upgrades" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-white/10 border-purple-500/20">
              <TabsTrigger value="upgrades" className="data-[state=active]:bg-purple-600">
                Upgrades
              </TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-purple-600">
                Recent Games
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upgrades">
              <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Upgrade Shop</CardTitle>
                  <CardDescription className="text-purple-200">
                    Spend your coins on permanent upgrades
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <UpgradeShop
                    userCoins={user.totalCoins}
                    userUpgrades={userUpgrades}
                    onPurchase={handlePurchase}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Recent Games
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Your last 20 games
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {recentGames.length === 0 ? (
                    <div className="text-center py-8 text-purple-200">
                      <Gamepad2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No games played yet.</p>
                      <Link href="/training">
                        <Button className="mt-4 bg-purple-600 hover:bg-purple-700">Play Now</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {recentGames.map((game, index) => {
                        const modeDisplay = getModeDisplay(game.gameMode as 'classic' | 'rush' | 'survival')
                        return (
                          <motion.div
                            key={game.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="flex items-center gap-4 p-3 rounded-lg bg-white/5"
                          >
                            <Badge
                              className={`${
                                game.gameMode === 'classic'
                                  ? 'bg-purple-600'
                                  : game.gameMode === 'rush'
                                  ? 'bg-orange-600'
                                  : 'bg-red-600'
                              }`}
                            >
                              {modeDisplay?.name}
                            </Badge>
                            <div className="flex-1">
                              <p className="text-purple-200 text-sm">
                                {game.completedAt ? formatDate(game.completedAt) : 'N/A'}
                              </p>
                            </div>
                            <div className="flex items-center gap-4 text-sm">
                              <div className="text-center">
                                <p className="text-yellow-400 font-bold">{game.score.toLocaleString()}</p>
                                <p className="text-purple-300 text-xs">Score</p>
                              </div>
                              <div className="text-center hidden sm:block">
                                <p className="text-green-400 font-bold">{game.accuracy}%</p>
                                <p className="text-purple-300 text-xs">Accuracy</p>
                              </div>
                              <div className="text-center hidden sm:block">
                                <p className="text-orange-400 font-bold">{game.maxStreak}</p>
                                <p className="text-purple-300 text-xs">Streak</p>
                              </div>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  )
}
