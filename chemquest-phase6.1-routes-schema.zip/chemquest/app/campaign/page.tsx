'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Map, Lock, CheckCircle, Star, ArrowLeft, Loader2,
  Beaker, Flame, Shield, Crown,
} from 'lucide-react';
import { toast } from 'sonner';

// Campaign data - will be loaded from campaign.json in future
const WORLDS = [
  {
    id: 'module-1',
    name: 'Module 1: Properties & Structure of Matter',
    description: 'Atomic structure, periodic table, bonding, and intermolecular forces.',
    chambers: [
      { id: 'm1-c1', name: 'Atomic Structure', topic: 'atomic-structure', free: true },
      { id: 'm1-c2', name: 'Periodic Table Trends', topic: 'periodic-table', free: true },
      { id: 'm1-c3', name: 'Chemical Bonding', topic: 'bonding', free: true },
      { id: 'm1-c4', name: 'Intermolecular Forces', topic: 'intermolecular-forces', free: true },
    ],
    boss: { id: 'acid-baron', name: 'The Acid Baron' },
    free: true,
  },
  {
    id: 'module-2',
    name: 'Module 2: Introduction to Quantitative Chemistry',
    description: 'Moles, stoichiometry, concentrations, and gas laws.',
    chambers: [
      { id: 'm2-c1', name: 'The Mole Concept', topic: 'moles', free: false },
      { id: 'm2-c2', name: 'Stoichiometry', topic: 'stoichiometry', free: false },
      { id: 'm2-c3', name: 'Concentration & Dilution', topic: 'concentration', free: false },
      { id: 'm2-c4', name: 'Gas Laws', topic: 'gas-laws', free: false },
    ],
    boss: { id: 'mole-master', name: 'The Mole Master' },
    free: false,
  },
  {
    id: 'module-3',
    name: 'Module 3: Reactive Chemistry',
    description: 'Types of reactions, rates, and energy changes.',
    chambers: [
      { id: 'm3-c1', name: 'Types of Reactions', topic: 'reaction-types', free: false },
      { id: 'm3-c2', name: 'Reaction Rates', topic: 'rates', free: false },
      { id: 'm3-c3', name: 'Energy Changes', topic: 'thermochem', free: false },
    ],
    boss: { id: 'reaction-king', name: 'The Reaction King' },
    free: false,
  },
];

interface ProgressEntry {
  chamberId: string;
  completed: boolean;
  bestScore: number;
  xpEarned: number;
}

export default function CampaignPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState<ProgressEntry[]>([]);
  const [userTier, setUserTier] = useState('free');

  useEffect(() => {
    async function load() {
      try {
        const meRes = await fetch('/api/auth/me');
        if (!meRes.ok) { router.push('/auth/login'); return; }
        const meData = await meRes.json();
        setUserTier(meData.user?.subscriptionTier || 'free');

        const progRes = await fetch('/api/campaign/progress');
        if (progRes.ok) {
          const progData = await progRes.json();
          setProgress(progData.progress || []);
        }
      } catch {
        toast.error('Failed to load campaign data');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [router]);

  const getChamberProgress = (chamberId: string) =>
    progress.find((p) => p.chamberId === chamberId);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-amber-950/20 to-slate-950 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-amber-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-amber-950/20 to-slate-950">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/hub">
            <Button variant="ghost" className="text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Hub
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Map className="w-8 h-8 text-amber-400" /> Campaign Mode
            </h1>
            <p className="text-white/60">Progress through HSC Chemistry modules</p>
          </div>
        </div>

        {/* Worlds */}
        <div className="space-y-8 max-w-4xl mx-auto">
          {WORLDS.map((world, wi) => {
            const isLocked = !world.free && userTier === 'free';
            return (
              <motion.div
                key={world.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: wi * 0.1 }}
              >
                <Card className={`bg-white/5 border-white/10 ${isLocked ? 'opacity-60' : ''}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                          {world.name}
                          {isLocked && <Lock className="w-4 h-4 text-yellow-500" />}
                          {!isLocked && world.free && (
                            <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">Free</Badge>
                          )}
                        </h2>
                        <p className="text-white/60 text-sm mt-1">{world.description}</p>
                      </div>
                    </div>

                    {/* Chambers */}
                    <div className="grid md:grid-cols-2 gap-3 mb-4">
                      {world.chambers.map((chamber) => {
                        const prog = getChamberProgress(chamber.id);
                        const chamberLocked = !chamber.free && userTier === 'free';
                        return (
                          <div
                            key={chamber.id}
                            className={`p-3 rounded-lg border ${
                              prog?.completed
                                ? 'bg-green-500/10 border-green-500/30'
                                : chamberLocked
                                ? 'bg-white/5 border-white/10 opacity-50'
                                : 'bg-white/5 border-white/20 hover:bg-white/10'
                            } transition-all`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {prog?.completed ? (
                                  <CheckCircle className="w-5 h-5 text-green-400" />
                                ) : chamberLocked ? (
                                  <Lock className="w-5 h-5 text-yellow-500/50" />
                                ) : (
                                  <Beaker className="w-5 h-5 text-cyan-400" />
                                )}
                                <span className="text-white font-medium text-sm">{chamber.name}</span>
                              </div>
                              {prog?.bestScore ? (
                                <div className="flex items-center gap-1">
                                  <Star className="w-3 h-3 text-yellow-400" />
                                  <span className="text-yellow-300 text-xs">{prog.bestScore}</span>
                                </div>
                              ) : null}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Boss */}
                    <div className={`p-3 rounded-lg border border-red-500/30 bg-red-500/10 flex items-center justify-between`}>
                      <div className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-red-400" />
                        <span className="text-white font-bold text-sm">Boss: {world.boss.name}</span>
                      </div>
                      {isLocked ? (
                        <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-xs">
                          <Crown className="w-3 h-3 mr-1" /> Pro
                        </Badge>
                      ) : (
                        <Badge className="bg-red-500/20 text-red-300 border-red-500/30 text-xs">Challenge</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Upgrade CTA for free users */}
        {userTier === 'free' && (
          <div className="max-w-4xl mx-auto mt-8">
            <Card className="bg-gradient-to-r from-purple-500/20 to-cyan-500/20 border-purple-400/30">
              <CardContent className="p-6 text-center">
                <Crown className="w-10 h-10 text-yellow-400 mx-auto mb-3" />
                <h3 className="text-xl font-bold text-white mb-2">Unlock All Modules</h3>
                <p className="text-white/60 mb-4">
                  Upgrade to Pro to access Modules 2-8, all boss battles, and premium features.
                </p>
                <Button className="bg-gradient-to-r from-purple-500 to-cyan-500 text-white">
                  Coming Soon
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
