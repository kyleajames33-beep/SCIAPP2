'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Trophy, ArrowLeft, Loader2, Crown, Sparkles, 
  Medal, Coins, TrendingUp
} from 'lucide-react'
import { motion } from 'framer-motion'
import { toast } from 'sonner'

interface LeaderboardUser {
  id: string
  username: string
  displayName: string
  prestigeLevel: number
  lifetimeEarnings: number
  totalScore: number
  gamesPlayed: number
  bestStreak: number
}

export default function LeaderboardPage() {
  const router = useRouter()
  const [users, setUsers] = useState<LeaderboardUser[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<string | null>(null)

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        // Fetch leaderboard data
        const response = await fetch('/api/leaderboard')
        if (response.ok) {
          const data = await response.json()
          setUsers(data.users || [])
        } else {
          toast.error('Failed to load leaderboard')
        }

        // Get current user
        const meResponse = await fetch('/api/auth/me')
        if (meResponse.ok) {
          const meData = await meResponse.json()
          setCurrentUser(meData.user?.id || null)
        }
      } catch (error) {
        console.error('Failed to fetch leaderboard:', error)
        toast.error('Failed to load leaderboard')
      } finally {
        setIsLoading(false)
      }
    }

    fetchLeaderboard()
  }, [])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-400" />
      case 2:
        return <Medal className="w-6 h-6 text-gray-300" />
      case 3:
        return <Medal className="w-6 h-6 text-amber-600" />
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-gray-400 font-bold">{rank}</span>
    }
  }

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border-yellow-400/50'
      case 2:
        return 'bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-300/50'
      case 3:
        return 'bg-gradient-to-r from-amber-600/20 to-orange-600/20 border-amber-500/50'
      default:
        return 'bg-white/5 border-white/10'
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-purple-300 animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4 py-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                <Trophy className="w-8 h-8 text-yellow-400" />
                Global Leaderboard
              </h1>
              <p className="text-purple-200">Top 50 players ranked by Prestige & Earnings</p>
            </div>
          </div>
          <Link href="/profile">
            <Button variant="ghost" className="text-white hover:bg-white/10">
              My Profile
            </Button>
          </Link>
        </motion.div>

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4 mb-6"
        >
          <Card className="bg-yellow-500/10 border-yellow-400/30">
            <CardContent className="p-4 text-center">
              <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <p className="text-yellow-400 font-bold">1st Place</p>
              <p className="text-yellow-200/60 text-sm">Ultimate Champion</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-400/10 border-gray-300/30">
            <CardContent className="p-4 text-center">
              <Medal className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-300 font-bold">2nd Place</p>
              <p className="text-gray-300/60 text-sm">Elite Player</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-600/10 border-amber-500/30">
            <CardContent className="p-4 text-center">
              <Medal className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <p className="text-amber-600 font-bold">3rd Place</p>
              <p className="text-amber-600/60 text-sm">Rising Star</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Leaderboard List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-white/10 backdrop-blur-lg border-purple-500/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>Top Players</span>
                <Badge className="bg-purple-600">Top 50</Badge>
              </CardTitle>
              <CardDescription className="text-purple-200">
                Sorted by Prestige Level, then Lifetime Earnings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {users.length === 0 ? (
                <div className="text-center py-8 text-purple-200">
                  <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin opacity-50" />
                  <p>Loading leaderboard...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {users.map((user, index) => {
                    const rank = index + 1
                    const isCurrentUser = user.id === currentUser

                    return (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.03 }}
                        className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${
                          getRankStyle(rank)
                        } ${isCurrentUser ? 'ring-2 ring-blue-400 ring-offset-2 ring-offset-purple-900' : ''}`}
                      >
                        {/* Rank */}
                        <div className="w-12 h-12 flex items-center justify-center shrink-0">
                          {getRankIcon(rank)}
                        </div>

                        {/* User Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-white truncate">
                              {user.displayName}
                            </h3>
                            {user.prestigeLevel > 0 && (
                              <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-400/50">
                                <Sparkles className="w-3 h-3 mr-1" />
                                P{user.prestigeLevel}
                              </Badge>
                            )}
                            {isCurrentUser && (
                              <Badge className="bg-blue-500">You</Badge>
                            )}
                          </div>
                          <p className="text-purple-300 text-sm">@{user.username}</p>
                        </div>

                        {/* Stats */}
                        <div className="flex items-center gap-6 text-sm">
                          <div className="text-center hidden sm:block">
                            <div className="flex items-center gap-1 text-yellow-400">
                              <Coins className="w-4 h-4" />
                              <span className="font-bold">{user.lifetimeEarnings?.toLocaleString()}</span>
                            </div>
                            <p className="text-purple-300 text-xs">Lifetime</p>
                          </div>
                          <div className="text-center hidden sm:block">
                            <div className="flex items-center gap-1 text-purple-400">
                              <Trophy className="w-4 h-4" />
                              <span className="font-bold">{user.totalScore?.toLocaleString()}</span>
                            </div>
                            <p className="text-purple-300 text-xs">Score</p>
                          </div>
                          <div className="text-center">
                            <div className="flex items-center gap-1 text-orange-400">
                              <TrendingUp className="w-4 h-4" />
                              <span className="font-bold">{user.bestStreak}</span>
                            </div>
                            <p className="text-purple-300 text-xs">Best Streak</p>
                          </div>
                        </div>
                      </motion.div>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Footer CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 text-center"
        >
          <Link href="/training">
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8">
              Play Now to Climb the Ranks!
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
